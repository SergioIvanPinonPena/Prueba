import axios from "axios";
import { Outlet, Link } from "react-router-dom";
import React, { useState } from "react";
export default function (props) {
  const [values, setValues] = React.useState({
    email: "",
    password: ""
  });
  const [valuesr, setValuesr] = React.useState({
    name: "",
    lastname: "",
    email: "",
    password: "",
    passwordConfirmation: ""
  });
  const [data, setData] = React.useState({
    id: "",
    account_money: "",
    role: "",
    name: ""
  });
  const [datat, setDatat] = React.useState({
    doing: data.id,
    account: "",
    value: ""
  });
  const [sing, setSing] = React.useState({
    sing: ""
  });
  const handleChanget = (e) => {
    const { name, value } = e.target;
    setDatat((prevState) => {
      return {
        ...prevState,
        [name]: value
      };
    });
  };
  const handleChange = (event) => {
    const { name, value } = event.target;
    setValues((prevState) => {
      return {
        ...prevState,
        [name]: value
      };
    });
  };
  const handleChanger = (event) => {
    const { name, value } = event.target;
    setValuesr((prevState) => {
      return {
        ...prevState,
        [name]: value
      };
    });
  };
  if (sing.sing != true) {
    return (
      <div className="Auth-form-container">
        <form className="Auth-form">
          <div className="Auth-form-content">
            <h3 className="Auth-form-title">Sign In</h3>
            <div className="form-group mt-3">
              <label>Email address</label>
              <input
                type="email"
                name="email"
                className="form-control mt-1"
                placeholder="Enter email"
                onChange={handleChange}
              />
            </div>
            <div className="form-group mt-3">
              <label>Password</label>
              <input
                type="password"
                name="password"
                className="form-control mt-1"
                placeholder="Enter password"
                onChange={handleChange}
              />
            </div>
            <div className="d-grid gap-2 mt-3">
              <button
                className="btn btn-primary"
                onClick={(e) => {
                  e.preventDefault();
                  console.log(values);

                  var data = JSON.stringify({
                    password: values.password,
                    email: values.email
                  });

                  var config = {
                    method: "post",
                    maxBodyLength: Infinity,
                    url:
                      "https://site--resolute-mice--2r729rw9gdmc.code.run/users/login",
                    headers: {
                      "Content-Type": "application/json"
                    },
                    data: data
                  };

                  axios(config)
                    .then(function (response) {
                      return response;
                    })
                    .then((response) => {
                      console.log(response);

                      setSing((prevState) => {
                        return {
                          ...prevState,
                          sing: true
                        };
                      });
                      setData((prevState) => {
                        return {
                          ...prevState,
                          id: response.data.token.id,
                          name: response.data.token.name,
                          account_money: response.data.token.account_money,
                          role: response.data.token.role
                        };
                      });
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                }}
              >
                Submit
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
  if (data.role != 2) {
    return (
      <div className="Home">
        <div className="Auth-form-container">
          <form>
            <h1 className="display-4">DEPOSITA DINERO!!</h1>
            <small>Cuenta: {data.id}</small>
            <br />
            <small>Dinero en cuenta: {data.account_money}</small>
            <div className="form-group">
              <label htmlFor="exampleInputEmail1">cuenta</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputaccount"
                placeholder="cuenta de deposito"
                name="account"
                onChange={handleChanget}
              />
            </div>
            <div className="form-group">
              <label htmlFor="exampleInputPassword1">cantidad</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputquantity"
                placeholder="cantidad"
                name="value"
                onChange={handleChanget}
              />
            </div>
            <br></br>
            <button
              onClick={(e) => {
                e.preventDefault();
                var datas = JSON.stringify({
                  doing: data.id,
                  account: datat.account,
                  value: parseInt(datat.value)
                });

                var config = {
                  method: "post",
                  maxBodyLength: Infinity,
                  url:
                    "https://site--resolute-mice--2r729rw9gdmc.code.run/users/put_transaction",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  data: datas
                };

                axios(config)
                  .then((response) => {
                    setData((prevState) => {
                      return {
                        id: response.data.id,
                        role: response.data.role,
                        name: response.data.name,
                        account_money: response.data.amount
                      };
                    });
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }}
              type="submit"
              className="btn btn-primary"
            >
              Submit
            </button>
          </form>
        </div>
        <div className="Auth-form-container">
          <form>
            <h1 className="display-4">RETIRA DINERO!!</h1>
            <small>Cuenta: {data.id}</small>
            <br />
            <small>Dinero en cuenta: {data.account_money}</small>
            <div className="form-group">
              <label htmlFor="exampleInputPassword1">cantidad</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputquantity"
                placeholder="cantidad"
                name="value"
                onChange={handleChanget}
              />
            </div>
            <br></br>
            <button
              onClick={(e) => {
                e.preventDefault();
                var datas = JSON.stringify({
                  account: data.id,
                  value: datat.value
                });

                var config = {
                  method: "put",
                  maxBodyLength: Infinity,
                  url:
                    "https://site--resolute-mice--2r729rw9gdmc.code.run/users/transOut",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  data: datas
                };

                axios(config)
                  .then((response) => {
                    setData((prevState) => {
                      return {
                        id: response.data.id,
                        role: response.data.role,
                        name: response.data.name,
                        account_money: response.data.amount
                      };
                    });
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }}
              className="btn btn-primary"
            >
              Submit
            </button>
            <br></br>
          </form>
        </div>
        <div className="Auth-form-container">
          <form>
            <div className="Auth-form-content">
              <h3 className="Auth-form-title">Register User</h3>
              <div className="form-group mt-3">
                <label>nombre</label>
                <input
                  type="email"
                  className="form-control mt-1"
                  placeholder="e.g Jane"
                  onChange={handleChanger}
                  name="name"
                />
              </div>
              <div className="form-group mt-3">
                <label>apellido</label>
                <input
                  type="email"
                  className="form-control mt-1"
                  placeholder="e.g acosta"
                  onChange={handleChanger}
                  name="lastname"
                />
              </div>
              <div className="form-group mt-3">
                <label>Email address</label>
                <input
                  type="email"
                  className="form-control mt-1"
                  placeholder="Email Address"
                  onChange={handleChanger}
                  name="email"
                />
              </div>
              <div className="form-group mt-3">
                <label>Password</label>
                <input
                  type="password"
                  className="form-control mt-1"
                  placeholder="Password"
                  onChange={handleChanger}
                  name="password"
                />
              </div>
              <div className="form-group mt-3">
                <label>Confirmar password</label>
                <input
                  type="password"
                  className="form-control mt-1"
                  placeholder="Password"
                  onChange={handleChanger}
                  name="passwordConfirmation"
                />
              </div>
              <div className="d-grid gap-2 mt-3">
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    console.log(valuesr);

                    var data = JSON.stringify({
                      name: valuesr.name,
                      lastname: valuesr.lastname,
                      passwordConfirmation: valuesr.passwordConfirmation,
                      password: valuesr.password,
                      email: valuesr.email
                    });

                    var config = {
                      method: "post",
                      maxBodyLength: Infinity,
                      url:
                        "https://site--resolute-mice--2r729rw9gdmc.code.run/users/signup",
                      headers: {
                        "Content-Type": "application/json"
                      },
                      data: data
                    };

                    axios(config)
                      .then(function (response) {
                        return response;
                      })
                      .then((response) => {
                        console.log(response);
                        return alert("usuario creado");
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                  }}
                  type="submit"
                  className="btn btn-primary"
                >
                  Submit
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  } else {
    return (
      <div className="Home">
        <div className="Auth-form-container">
          <form>
            <h1 className="display-4">DEPOSITA DINERO!!</h1>
            <small>Cuenta: {data.id}</small>
            <br />
            <small>Dinero en cuenta: {data.account_money}</small>
            <div className="form-group">
              <label htmlFor="exampleInputEmail1">cuenta</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputaccount"
                placeholder="cuenta de deposito"
                name="account"
                onChange={handleChanget}
              />
            </div>
            <div className="form-group">
              <label htmlFor="exampleInputPassword1">cantidad</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputquantity"
                placeholder="cantidad"
                name="value"
                onChange={handleChanget}
              />
            </div>
            <br></br>
            <button
              onClick={(e) => {
                e.preventDefault();
                var datas = JSON.stringify({
                  doing: data.id,
                  account: datat.account,
                  value: parseInt(datat.value)
                });

                var config = {
                  method: "post",
                  maxBodyLength: Infinity,
                  url:
                    "https://site--resolute-mice--2r729rw9gdmc.code.run/users/put_transaction",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  data: datas
                };

                axios(config)
                  .then((response) => {
                    setData((prevState) => {
                      return {
                        id: response.data.id,
                        role: response.data.role,
                        name: response.data.name,
                        account_money: response.data.amount
                      };
                    });
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }}
              type="submit"
              className="btn btn-primary"
            >
              Submit
            </button>
          </form>
        </div>
        <div className="Auth-form-container">
          <form>
            <h1 className="display-4">RETIRA DINERO!!</h1>
            <small>Cuenta: {data.id}</small>
            <br />
            <small>Dinero en cuenta: {data.account_money}</small>
            <div className="form-group">
              <label htmlFor="exampleInputPassword1">cantidad</label>
              <input
                type="text"
                className="form-control"
                id="exampleInputquantity"
                placeholder="cantidad"
                name="value"
                onChange={handleChanget}
              />
            </div>
            <br></br>
            <button
              onClick={(e) => {
                e.preventDefault();
                var datas = JSON.stringify({
                  account: data.id,
                  value: datat.value
                });

                var config = {
                  method: "put",
                  maxBodyLength: Infinity,
                  url:
                    "https://site--resolute-mice--2r729rw9gdmc.code.run/users/transOut",
                  headers: {
                    "Content-Type": "application/json"
                  },
                  data: datas
                };

                axios(config)
                  .then((response) => {
                    setData((prevState) => {
                      return {
                        id: response.data.id,
                        role: response.data.role,
                        name: response.data.name,
                        account_money: response.data.amount
                      };
                    });
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
              }}
              className="btn btn-primary"
            >
              Submit
            </button>
            <br></br>
          </form>
        </div>
      </div>
    );
  }
}
